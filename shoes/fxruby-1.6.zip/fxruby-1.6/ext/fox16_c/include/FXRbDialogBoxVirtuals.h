public:
  // Overrides the base class version of execute()
  virtual FXuint execute(FXuint placement=PLACEMENT_CURSOR);
