public:
  // Overrides the base class version of setValue()
  virtual void setValue(FXint value,FXbool notify=FALSE);
