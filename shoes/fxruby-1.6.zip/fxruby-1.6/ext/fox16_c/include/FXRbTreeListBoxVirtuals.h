public:
  // Overrides the base class version of setCurrentItem()
  virtual void setCurrentItem(FXTreeItem* item,FXbool notify=FALSE);

