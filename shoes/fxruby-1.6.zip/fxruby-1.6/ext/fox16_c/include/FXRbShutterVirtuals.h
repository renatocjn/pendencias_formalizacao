public:
  // Overrides the base class version of setCurrent()
  virtual void setCurrent(FXint panel);
