public:
  // Overrides the base class version of resize()
  virtual void resize(FXint w,FXint h);
