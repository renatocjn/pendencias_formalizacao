public:
  /// Overrides the base class version of setCurrentItem()
  virtual void setCurrentItem(FXint index,FXbool notify=FALSE);

