public:
  // Overrides the base class version of getContentWidth()
  virtual FXint getContentWidth();

  // Overrides the base class version of getContentHeight()
  virtual FXint getContentHeight();

  // Overrides the base class version of getViewportWidth()
  virtual FXint getViewportWidth();

  // Overrides the base class version of getViewportHeight()
  virtual FXint getViewportHeight();

