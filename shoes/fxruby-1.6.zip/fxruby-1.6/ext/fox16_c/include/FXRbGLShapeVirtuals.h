protected:
  // Overrides the base class version of drawshape()
  virtual void drawshape(FXGLViewer* viewer);

public:
  // This is the publically accessible version
  void _drawshape(FXGLViewer* viewer);

