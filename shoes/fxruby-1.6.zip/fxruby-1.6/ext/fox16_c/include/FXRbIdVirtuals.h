public:
  // Overrides base class version of create()
  virtual void create();

  // Overrides base class version of detach()
  virtual void detach();

  // Overrides base class version of destroy()
  virtual void destroy();
