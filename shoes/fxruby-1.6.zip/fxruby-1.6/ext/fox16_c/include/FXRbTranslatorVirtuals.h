public:
  // Overrides the base class version of tr()
  virtual const FXchar* tr(const FXchar* context,const FXchar* message,const FXchar* hint) const;

