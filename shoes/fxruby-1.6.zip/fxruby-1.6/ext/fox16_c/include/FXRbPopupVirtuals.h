public:
  // Overrides the base class version of popup()
  virtual void popup(FXWindow* grabto,FXint x,FXint y,FXint w=0,FXint h=0);

  // Overrides the base class version of popdown()
  virtual void popdown();
