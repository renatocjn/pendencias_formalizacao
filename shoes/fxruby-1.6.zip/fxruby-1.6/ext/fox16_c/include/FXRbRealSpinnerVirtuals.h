public:
  // Overrides the base class version of setValue()
  virtual void setValue(FXdouble value,FXbool notify=FALSE);
